# TOOFAR? — Brand Prototype

## Brand idea
**TOOFAR?** trasforma ogni situazione in una domanda semplice: **Quanto è troppo?**

### Core line
**Judge first. Explain later.**

### Product language
- Chill
- Dipende
- Sketchy
- TOO FAR
- Dealbreaker

### Perché funziona
Il nome non limita l’app alle red flag. Può vivere su relazioni, amicizia, soldi, famiglia, morale, gelosia, privacy e hot takes.

### Nota
Questa è una direzione creativa/prodotto. Prima di registrare il marchio va eseguita una verifica formale di trademark, domini e handle social.
