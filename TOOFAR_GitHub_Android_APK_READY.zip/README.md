# TOOFAR?

**Quanto è troppo?**

Primo prototipo Android installabile di TOOFAR?.

## Generare l'APK

Ogni push sul branch `main` avvia automaticamente GitHub Actions.

1. Apri **Actions**
2. Seleziona **Build Android APK**
3. Apri l'ultima build completata
4. In fondo, sotto **Artifacts**, scarica `TOOFAR-debug-apk`
5. Estrai lo ZIP
6. Installa `app-debug.apk` su Android

## Stato del progetto

Questa è una demo locale del prototipo.
Le interazioni UI funzionano, ma backend, account, database, votazioni reali,
notifiche e confronto multiutente verranno sviluppati successivamente.

Package Android: `com.toofar.app`
